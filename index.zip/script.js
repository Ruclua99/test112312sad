// Chờ DOM load xong
document.addEventListener('DOMContentLoaded', function() {
    // Hiệu ứng typing cho tên
    const nameElement = document.getElementById('name');
    const nameText = 'Phí Ngọc Tuấn'; // Thay đổi tên ở đây
    let nameIndex = 0;
    
    function typeName() {
        if (nameIndex < nameText.length) {
            nameElement.textContent += nameText.charAt(nameIndex);
            nameIndex++;
            setTimeout(typeName, 100);
        }
    }
    
    // Bắt đầu hiệu ứng typing sau 1 giây
    setTimeout(() => {
        nameElement.textContent = '';
        typeName();
    }, 1000);
    
    // Hiệu ứng hover cho skill tags
    const skillTags = document.querySelectorAll('.skill-tag');
    skillTags.forEach(tag => {
        tag.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-3px) scale(1.05)';
        });
        
        tag.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });
    
    // Hiệu ứng scroll cho các section
    const sections = document.querySelectorAll('section');
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    sections.forEach(section => {
        section.style.opacity = '0';
        section.style.transform = 'translateY(30px)';
        section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(section);
    });
    
    // Thêm hiệu ứng click cho avatar
    const avatar = document.querySelector('.avatar-placeholder');
    avatar.addEventListener('click', function() {
        this.style.transform = 'scale(0.95)';
        setTimeout(() => {
            this.style.transform = 'scale(1)';
        }, 150);
        
        // Hiển thị thông báo
        showNotification('Cảm ơn bạn đã ghé thăm! 👋');
    });
    
    // Thêm hiệu ứng cho các link liên hệ
    const contactLinks = document.querySelectorAll('.contact-info a');
    contactLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            showNotification('Liên kết sẽ được mở trong tab mới! 🔗');
        });
    });
    
    // Hàm hiển thị thông báo
    function showNotification(message) {
        // Tạo element thông báo
        const notification = document.createElement('div');
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 15px 20px;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            font-weight: 500;
            transform: translateX(100%);
            transition: transform 0.3s ease;
        `;
        
        document.body.appendChild(notification);
        
        // Hiệu ứng xuất hiện
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // Tự động ẩn sau 3 giây
        setTimeout(() => {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }
    
    // Thêm hiệu ứng parallax nhẹ cho background
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const parallax = document.querySelector('body');
        const speed = scrolled * 0.5;
        
        parallax.style.backgroundPosition = `center ${speed}px`;
    });
    
    // Thêm hiệu ứng loading khi trang load
    window.addEventListener('load', function() {
        const container = document.querySelector('.container');
        container.style.opacity = '0';
        container.style.transform = 'translateY(50px)';
        
        setTimeout(() => {
            container.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
            container.style.opacity = '1';
            container.style.transform = 'translateY(0)';
        }, 100);
    });
    
    // Thêm hiệu ứng cho các skill tag khi hover
    const skillContainer = document.querySelector('.skill-tags');
    skillContainer.addEventListener('mouseenter', function() {
        this.style.transform = 'scale(1.02)';
    });
    
    skillContainer.addEventListener('mouseleave', function() {
        this.style.transform = 'scale(1)';
    });
    
    // Thêm hiệu ứng typing cho description
    const descriptionElement = document.getElementById('description');
    const descriptionText = 'Tôi là một nhà phát triển web đam mê với công nghệ và luôn muốn học hỏi những điều mới. Tôi thích tạo ra những ứng dụng web đẹp và hữu ích cho người dùng.';
    
    function typeDescription() {
        let descIndex = 0;
        descriptionElement.textContent = '';
        
        function typeChar() {
            if (descIndex < descriptionText.length) {
                descriptionElement.textContent += descriptionText.charAt(descIndex);
                descIndex++;
                setTimeout(typeChar, 30);
            }
        }
        
        setTimeout(typeChar, 2000);
    }
    
    // Bắt đầu hiệu ứng typing cho description
    setTimeout(typeDescription, 2000);
});

// Thêm một số thông tin mẫu có thể chỉnh sửa
const personalInfo = {
    name: 'Nguyễn Văn A',
    email: 'nguyenvana@example.com',
    phone: '+84 123 456 789',
    website: 'www.nguyenvana.com',
    description: 'Tôi là một nhà phát triển web đam mê với công nghệ và luôn muốn học hỏi những điều mới. Tôi thích tạo ra những ứng dụng web đẹp và hữu ích cho người dùng.'
};

// Hàm cập nhật thông tin cá nhân
function updatePersonalInfo() {
    document.getElementById('name').textContent = personalInfo.name;
    document.getElementById('email').textContent = personalInfo.email;
    document.getElementById('phone').textContent = personalInfo.phone;
    document.getElementById('website').textContent = personalInfo.website;
    document.getElementById('description').textContent = personalInfo.description;
}
